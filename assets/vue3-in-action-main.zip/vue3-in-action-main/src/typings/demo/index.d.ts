/// <reference path="./good.d.ts" />
/// <reference path="./authority.d.ts" />